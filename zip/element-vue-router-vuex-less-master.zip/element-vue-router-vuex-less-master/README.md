# 多语言+element+vue-router+vuex+less

> 基于Vue.js 2.0、element-ui、vue-i18n、vue-router、vuex、less搭建的简单Demo
> ####默认问地址: localhost:8080
> 仅供学习参考，如有不足之处，欢迎多多指教

``` bash
npm install
```

## Develop

``` bash
# serve with hot reload at localhost:8080
npm run dev
```

## Build

``` bash
# build for production with minification
npm run build
```
