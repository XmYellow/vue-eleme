<template>
	<div class="toBeConfirmed">
		{{$t('others.second')}}
	</div>
</template>
<script>
export default{
	name: 'toBeConfirmed'
}	
</script>