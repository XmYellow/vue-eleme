<template>
	<div class="dashboard">
		{{$t('others.first')}}
	</div>
</template>
<script>
export default{
	name: 'dashboard'
}
</script>
<style>
	
</style>