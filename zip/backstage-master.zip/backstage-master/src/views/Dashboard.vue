<template>
<div class="dashboard">

</div>
</template>

<script>
export default {
  data() {
    return {

    }
  },
  methods: {

  }
}
</script>

<style lang="scss">
@import '../assets/styles/fn.scss';
.dashboard {}</style>
