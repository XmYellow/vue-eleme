export const loggedIn = state => state.auth.user !== null
export const currentUser = state => state.auth.user
export const currentMenu = state => state.auth.menu
