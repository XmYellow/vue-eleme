// import * as types from '../mutation-types'

const state = {
  breadcrumb: null
}

const mutations = {
  // [types.AUTH_LOGIN](state, user) {
  //   state.user = user
  //   window.sessionStorage.setItem('backstage_auth_user', JSON.stringify(user))
  // },
  // [types.AUTH_LOGOUT](state) {
  //   state.user = null
  //   window.sessionStorage.removeItem('backstage_auth_user')
  // }
}

export default {
  state,
  mutations
}
