<template>
<div id="app">
  <router-view></router-view>
</div>
</template>

<script>
export default {
  data() {
    return {}
  }
}
</script>

<style lang="scss">
@import '~normalize.css';
@import '~element-ui/lib/theme-default/index.css';
@import '~animate.css';
@import '~nprogress/nprogress.css';
</style>
