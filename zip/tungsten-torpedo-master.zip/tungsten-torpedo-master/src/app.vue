<template>
<div id="app">


    <el-menu mode="horizontal" @select="menuHandler">
        <img class="vue-logo" src="./assets/vue-logo.png" @click="menuHandler('/')" />
        <el-menu-item index="element">Element</el-menu-item>
        <el-menu-item index="about">About</el-menu-item>
    </el-menu>


    <router-view></router-view>

</div>
</template>


<script>
export default {

    methods: {

        menuHandler: function(index){
            this.$router.push(index)
        },
    },

};
</script>


<style>
    :root {
        margin: 0;
        padding: 0;
        font-family: sans-serif;
    }
    body {
        margin: 0;
        padding: 0;
    }
    .vue-logo {
        cursor: pointer;
        height: 30px;
        padding: 15px 20px;
        float: left;
    }
</style>
