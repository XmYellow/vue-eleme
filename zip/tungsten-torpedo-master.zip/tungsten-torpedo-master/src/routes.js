module.exports = [

    {
        path: '',
        component: require('./components/landing.vue'),
    },

    {
        path: '/element',
        component: require('./components/element.vue'),
    },

    {
        path: '/about',
        component: require('./components/about.vue'),
    },

];
