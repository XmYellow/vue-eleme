<template>
<div class="component">
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Necessitatibus quidem temporibus voluptate. Sint alias quam omnis, voluptates officiis cupiditate quia, iure cum et accusamus eos facere architecto possimus optio eligendi.
</div>
</template>


<script>
export default {

    data: function(){
        return {
        }
    },

};
</script>


<style scoped>
    .component {
        padding: 20px;
    }
</style>
