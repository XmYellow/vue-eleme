<template>
<div class="component">

    <div>Hello! This is a landing page of tungsten-torpedo.</div>


</div>
</template>


<script>
export default {

};
</script>


<style scoped>
    .component {
        padding: 20px;
    }
</style>
