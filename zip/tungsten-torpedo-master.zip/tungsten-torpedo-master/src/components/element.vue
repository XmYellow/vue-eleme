<template>
<div class="component">

    <el-select v-model="value" placeholder="Select" filterable multiple>
        <el-option v-for="item in options" :label="item.label" :value="item.value"></el-option>
    </el-select>


    <div class="top-margin">Element UI Select Test: {{value && value.length ? value : 'No Value Selected'}}</div>

</div>
</template>


<script>
export default {

    data: function(){
        return {

            value: '',

            options: [
                {
                    value: 'Option1',
                    label: 'Option1',
                },
                {
                    value: 'Option2',
                    label: 'Option2',
                },
                {
                    value: 'Option3',
                    label: 'Option3',
                },
                {
                    value: 'Option4',
                    label: 'Option4',
                },
                {
                    value: 'Option5',
                    label: 'Option5',
                },
            ],


        }
    },

};
</script>


<style scoped>
    .component {
        padding: 20px;
    }
    .top-margin {
        margin-top: 20px;
    }
</style>
