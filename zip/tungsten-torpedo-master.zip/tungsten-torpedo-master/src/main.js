/*------------------------------------*\
    Imports
\*------------------------------------*/
import Vue from 'vue';
import Vuex from 'vuex';
import VueRouter from 'vue-router';
import { Button, Select, Option, Menu, MenuItem } from 'element-ui';
import ElementUILocale from 'element-ui/lib/locale';
import ElementUILangEn from 'element-ui/lib/locale/lang/en';



/*------------------------------------*\
    Register Modules
\*------------------------------------*/
// vue-router
Vue.use(VueRouter)
var router = new VueRouter({
    routes: require('./routes.js'),
    mode: 'history',
});

// vuex
Vue.use(Vuex);

// element-ui
ElementUILocale.use(ElementUILangEn);



/*------------------------------------*\
    Components
\*------------------------------------*/

// Element UI - Vue.component or Vue.use(Button)
Vue.component('el-button', Button);
Vue.component('el-select', Select);
Vue.component('el-option', Option);
Vue.component('el-menu', Menu);
Vue.component('el-menu-item', MenuItem);

// Application
Vue.component('app', require('./app.vue'));



/*------------------------------------*\
    Render App
\*------------------------------------*/
/* eslint-disable no-new */
new Vue({
    router,
    el: '#app',
    template: '<app></app>',
})

